// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'order_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$watchOrderHash() => r'74a06765e89ba48d9cc7d29c79a9554c212708eb';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

/// Stream لطلب معين — للـ tracking screen
///
/// Copied from [watchOrder].
@ProviderFor(watchOrder)
const watchOrderProvider = WatchOrderFamily();

/// Stream لطلب معين — للـ tracking screen
///
/// Copied from [watchOrder].
class WatchOrderFamily extends Family<AsyncValue<AppOrder>> {
  /// Stream لطلب معين — للـ tracking screen
  ///
  /// Copied from [watchOrder].
  const WatchOrderFamily();

  /// Stream لطلب معين — للـ tracking screen
  ///
  /// Copied from [watchOrder].
  WatchOrderProvider call(
    String orderId,
  ) {
    return WatchOrderProvider(
      orderId,
    );
  }

  @override
  WatchOrderProvider getProviderOverride(
    covariant WatchOrderProvider provider,
  ) {
    return call(
      provider.orderId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'watchOrderProvider';
}

/// Stream لطلب معين — للـ tracking screen
///
/// Copied from [watchOrder].
class WatchOrderProvider extends AutoDisposeStreamProvider<AppOrder> {
  /// Stream لطلب معين — للـ tracking screen
  ///
  /// Copied from [watchOrder].
  WatchOrderProvider(
    String orderId,
  ) : this._internal(
          (ref) => watchOrder(
            ref as WatchOrderRef,
            orderId,
          ),
          from: watchOrderProvider,
          name: r'watchOrderProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$watchOrderHash,
          dependencies: WatchOrderFamily._dependencies,
          allTransitiveDependencies:
              WatchOrderFamily._allTransitiveDependencies,
          orderId: orderId,
        );

  WatchOrderProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.orderId,
  }) : super.internal();

  final String orderId;

  @override
  Override overrideWith(
    Stream<AppOrder> Function(WatchOrderRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: WatchOrderProvider._internal(
        (ref) => create(ref as WatchOrderRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        orderId: orderId,
      ),
    );
  }

  @override
  AutoDisposeStreamProviderElement<AppOrder> createElement() {
    return _WatchOrderProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is WatchOrderProvider && other.orderId == orderId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, orderId.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin WatchOrderRef on AutoDisposeStreamProviderRef<AppOrder> {
  /// The parameter `orderId` of this provider.
  String get orderId;
}

class _WatchOrderProviderElement
    extends AutoDisposeStreamProviderElement<AppOrder> with WatchOrderRef {
  _WatchOrderProviderElement(super.provider);

  @override
  String get orderId => (origin as WatchOrderProvider).orderId;
}

String _$customerOrdersHash() => r'01a0d039570df2ce24ced0904d13d3fd7cc04496';

/// طلبات الزبون الحالي
///
/// Copied from [customerOrders].
@ProviderFor(customerOrders)
final customerOrdersProvider =
    AutoDisposeStreamProvider<List<AppOrder>>.internal(
  customerOrders,
  name: r'customerOrdersProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$customerOrdersHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef CustomerOrdersRef = AutoDisposeStreamProviderRef<List<AppOrder>>;
String _$shopOrdersHash() => r'0bd64133b7dacef539b9aabf24a0288d30e422d4';

/// طلبات المحل (للتاجر)
///
/// Copied from [shopOrders].
@ProviderFor(shopOrders)
const shopOrdersProvider = ShopOrdersFamily();

/// طلبات المحل (للتاجر)
///
/// Copied from [shopOrders].
class ShopOrdersFamily extends Family<AsyncValue<List<AppOrder>>> {
  /// طلبات المحل (للتاجر)
  ///
  /// Copied from [shopOrders].
  const ShopOrdersFamily();

  /// طلبات المحل (للتاجر)
  ///
  /// Copied from [shopOrders].
  ShopOrdersProvider call(
    String shopId,
  ) {
    return ShopOrdersProvider(
      shopId,
    );
  }

  @override
  ShopOrdersProvider getProviderOverride(
    covariant ShopOrdersProvider provider,
  ) {
    return call(
      provider.shopId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'shopOrdersProvider';
}

/// طلبات المحل (للتاجر)
///
/// Copied from [shopOrders].
class ShopOrdersProvider extends AutoDisposeStreamProvider<List<AppOrder>> {
  /// طلبات المحل (للتاجر)
  ///
  /// Copied from [shopOrders].
  ShopOrdersProvider(
    String shopId,
  ) : this._internal(
          (ref) => shopOrders(
            ref as ShopOrdersRef,
            shopId,
          ),
          from: shopOrdersProvider,
          name: r'shopOrdersProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$shopOrdersHash,
          dependencies: ShopOrdersFamily._dependencies,
          allTransitiveDependencies:
              ShopOrdersFamily._allTransitiveDependencies,
          shopId: shopId,
        );

  ShopOrdersProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.shopId,
  }) : super.internal();

  final String shopId;

  @override
  Override overrideWith(
    Stream<List<AppOrder>> Function(ShopOrdersRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: ShopOrdersProvider._internal(
        (ref) => create(ref as ShopOrdersRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        shopId: shopId,
      ),
    );
  }

  @override
  AutoDisposeStreamProviderElement<List<AppOrder>> createElement() {
    return _ShopOrdersProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is ShopOrdersProvider && other.shopId == shopId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, shopId.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin ShopOrdersRef on AutoDisposeStreamProviderRef<List<AppOrder>> {
  /// The parameter `shopId` of this provider.
  String get shopId;
}

class _ShopOrdersProviderElement
    extends AutoDisposeStreamProviderElement<List<AppOrder>>
    with ShopOrdersRef {
  _ShopOrdersProviderElement(super.provider);

  @override
  String get shopId => (origin as ShopOrdersProvider).shopId;
}

String _$availableDeliveriesHash() =>
    r'd31cc9adcea39df18b62d992f61e72f7d658acf4';

/// طلبات التوصيل المتاحة (للسائق)
///
/// Copied from [availableDeliveries].
@ProviderFor(availableDeliveries)
final availableDeliveriesProvider =
    AutoDisposeStreamProvider<List<AppOrder>>.internal(
  availableDeliveries,
  name: r'availableDeliveriesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$availableDeliveriesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef AvailableDeliveriesRef = AutoDisposeStreamProviderRef<List<AppOrder>>;
String _$checkoutControllerHash() =>
    r'9d60c4ac43f1c2b3d6e19074fd89238f3ad80725';

/// Checkout Controller — يتحكم في عملية إرسال الطلب
///
/// Copied from [CheckoutController].
@ProviderFor(CheckoutController)
final checkoutControllerProvider = AutoDisposeNotifierProvider<
    CheckoutController, AsyncValue<String?>>.internal(
  CheckoutController.new,
  name: r'checkoutControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$checkoutControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CheckoutController = AutoDisposeNotifier<AsyncValue<String?>>;
String _$orderStatusControllerHash() =>
    r'131d0dc6b2288959049f2ececfd6db4aa2ac0b0e';

/// تحديث حالة الطلب (للتاجر والسائق)
///
/// Copied from [OrderStatusController].
@ProviderFor(OrderStatusController)
final orderStatusControllerProvider = AutoDisposeNotifierProvider<
    OrderStatusController, AsyncValue<void>>.internal(
  OrderStatusController.new,
  name: r'orderStatusControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$orderStatusControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$OrderStatusController = AutoDisposeNotifier<AsyncValue<void>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
