// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appName => 'سوق القرية';

  @override
  String get homeTab => 'الرئيسية';

  @override
  String get ordersTab => 'طلباتي';

  @override
  String get cartTab => 'السلة';

  @override
  String get profileTab => 'حسابي';

  @override
  String get phoneEntryTitle => 'أدخل رقم هاتفك';

  @override
  String get phoneEntryHint => '01XXXXXXXXX';

  @override
  String get sendOtpButton => 'إرسال رمز التحقق';

  @override
  String get otpTitle => 'أدخل رمز التحقق';

  @override
  String get otpSubtitle => 'تم إرسال رمز التحقق إلى رقمك';

  @override
  String get verifyButton => 'تحقق';

  @override
  String get resendCode => 'إعادة إرسال الرمز';

  @override
  String get roleSelectionTitle => 'اختر نوع الحساب';

  @override
  String get roleVillager => 'زبون';

  @override
  String get roleVendor => 'صاحب محل';

  @override
  String get roleDriver => 'سائق توصيل';

  @override
  String get cartEmpty => 'السلة فارغة';

  @override
  String get addToCart => 'أضف إلى السلة';

  @override
  String get checkoutButton => 'إتمام الطلب';

  @override
  String get orderTotal => 'الإجمالي';

  @override
  String get deliveryFee => 'رسوم التوصيل';

  @override
  String get subtotal => 'المجموع الفرعي';

  @override
  String get orderStatusPending => 'قيد الانتظار';

  @override
  String get orderStatusAccepted => 'تم القبول';

  @override
  String get orderStatusPreparing => 'جاري التجهيز';

  @override
  String get orderStatusInTransit => 'في الطريق';

  @override
  String get orderStatusDelivered => 'تم التوصيل';

  @override
  String get orderStatusCancelled => 'ملغي';

  @override
  String get errorGeneric => 'حدث خطأ ما، حاول مرة أخرى';

  @override
  String get errorNoInternet => 'تأكد من اتصالك بالإنترنت وحاول مرة أخرى';

  @override
  String get offlineBanner =>
      'أنت غير متصل بالإنترنت - سيتم المزامنة عند عودة الاتصال';

  @override
  String get retryButton => 'إعادة المحاولة';

  @override
  String get cancelButton => 'إلغاء';

  @override
  String get confirmButton => 'تأكيد';
}
