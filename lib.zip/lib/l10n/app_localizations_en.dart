// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appName => 'Village Market';

  @override
  String get homeTab => 'Home';

  @override
  String get ordersTab => 'My Orders';

  @override
  String get cartTab => 'Cart';

  @override
  String get profileTab => 'Profile';

  @override
  String get phoneEntryTitle => 'Enter your phone number';

  @override
  String get phoneEntryHint => '01XXXXXXXXX';

  @override
  String get sendOtpButton => 'Send verification code';

  @override
  String get otpTitle => 'Enter verification code';

  @override
  String get otpSubtitle => 'A code was sent to your number';

  @override
  String get verifyButton => 'Verify';

  @override
  String get resendCode => 'Resend code';

  @override
  String get roleSelectionTitle => 'Choose account type';

  @override
  String get roleVillager => 'Customer';

  @override
  String get roleVendor => 'Shop owner';

  @override
  String get roleDriver => 'Delivery driver';

  @override
  String get cartEmpty => 'Your cart is empty';

  @override
  String get addToCart => 'Add to cart';

  @override
  String get checkoutButton => 'Checkout';

  @override
  String get orderTotal => 'Total';

  @override
  String get deliveryFee => 'Delivery fee';

  @override
  String get subtotal => 'Subtotal';

  @override
  String get orderStatusPending => 'Pending';

  @override
  String get orderStatusAccepted => 'Accepted';

  @override
  String get orderStatusPreparing => 'Preparing';

  @override
  String get orderStatusInTransit => 'In transit';

  @override
  String get orderStatusDelivered => 'Delivered';

  @override
  String get orderStatusCancelled => 'Cancelled';

  @override
  String get errorGeneric => 'Something went wrong, please try again';

  @override
  String get errorNoInternet => 'Check your internet connection and try again';

  @override
  String get offlineBanner =>
      'You\'re offline - changes will sync when connection is restored';

  @override
  String get retryButton => 'Retry';

  @override
  String get cancelButton => 'Cancel';

  @override
  String get confirmButton => 'Confirm';
}
